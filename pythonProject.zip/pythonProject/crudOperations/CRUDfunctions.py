import tkinter as tk
from tkinter import messagebox

class StudentForm(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Student Management")

        # Input fields for student details
        self.name_label = tk.Label(self, text="Name:")
        self.name_label.grid(row=0, column=0)
        self.name_entry = tk.Entry(self)
        self.name_entry.grid(row=0, column=1)

        self.student_number_label = tk.Label(self, text="Student Number:")
        self.student_number_label.grid(row=1, column=0)
        self.student_number_entry = tk.Entry(self)
        self.student_number_entry.grid(row=1, column=1)

        self.course_label = tk.Label(self, text="Course:")
        self.course_label.grid(row=2, column=0)
        self.course_entry = tk.Entry(self)
        self.course_entry.grid(row=2, column=1)

        # Buttons for CRUD operations
        self.add_button = tk.Button(self, text="Add Student", command=self.add_student)
        self.add_button.grid(row=3, column=0, pady=10)

        self.update_button = tk.Button(self, text="Update Student", command=self.update_student)
        self.update_button.grid(row=3, column=1, pady=10)

        self.delete_button = tk.Button(self, text="Delete Student", command=self.delete_student)
        self.delete_button.grid(row=3, column=2, pady=10)

    def add_student(self):
        name = self.name_entry.get()
        student_number = self.student_number_entry.get()
        course = self.course_entry.get()

        # Validate input
        if name and student_number and course:
            # Perform add operation (implement this part)
            messagebox.showinfo("Success", "Student added successfully!")
            self.clear_entries()
        else:
            messagebox.showerror("Error", "Please fill in all fields.")

    def update_student(self):
        # Implement update operation
        pass

    def delete_student(self):
        # Implement delete operation
        pass

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.student_number_entry.delete(0, tk.END)
        self.course_entry.delete(0, tk.END)


if __name__ == "__main__":
    root = tk.Tk()
    app = StudentForm(root)
    app.mainloop()