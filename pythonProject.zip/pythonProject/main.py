import tkinter as tk


class StudentRegistrationWindow:
    def grab_set(self):
        pass


class LecturerRegistrationWindow:
    def grab_set(self):
        pass


def open_student_registration():
    student_registration_window = StudentRegistrationWindow()
    student_registration_window.grab_set()


def open_lecturer_registration():
    lecturer_registration_window = LecturerRegistrationWindow()
    lecturer_registration_window.grab_set()


class MainApplication(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Student and Lecturer Registration System")

        self.student_button = tk.Button(self, text="Register Student", command=open_student_registration)
        self.student_button.pack(pady=10)

        self.lecturer_button = tk.Button(self, text="Register Lecturer", command=open_lecturer_registration)
        self.lecturer_button.pack(pady=10)
