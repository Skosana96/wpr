from tkinter import messagebox

import tk


class StudentRegistrationWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Student Registration")

        self.name_label = tk.Label(self, text="Name:")
        self.name_label.grid(row=0, column=0)
        self.name_entry = tk.Entry(self)
        self.name_entry.grid(row=0, column=1)

        self.student_number_label = tk.Label(self, text="Student Number:")
        self.student_number_label.grid(row=1, column=0)
        self.student_number_entry = tk.Entry(self)
        self.student_number_entry.grid(row=1, column=1)

        self.course_label = tk.Label(self, text="Course:")
        self.course_label.grid(row=2, column=0)
        self.course_entry = tk.Entry(self)
        self.course_entry.grid(row=2, column=1)

        self.register_button = tk.Button(self, text="Register", command=self.register_student)
        self.register_button.grid(row=3, column=0, columnspan=2, pady=10)

    def register_student(self):
        name = self.name_entry.get()
        student_number = self.student_number_entry.get()
        course = self.course_entry.get()

        # Validate input
        if name and student_number and course:
            # Store data in the database (implement this part)
            print("Student registered successfully!")
        else:
            messagebox.showerror("Error", "Please fill in all fields.")

    def title(self, param):
        pass


class LecturerRegistrationWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Lecturer Registration")

    def title(self, param):
        pass
