import tk


class StudentForm:
    def grab_set(self):
        pass


class LecturerForm:
    def grab_set(self):
        pass


class MainApplication(tk.Tk):
    def __init__(self):
        super().__init__()
        self.lecturer_button = tk.Button(self, text="Manage Lecturers", command=self.open_lecturer_form)
        self.student_button = tk.Button(self, text="Manage Students", command=self.open_student_form)
        self.title("Student and Lecturer Management System")
        self.create_widgets()

    def create_widgets(self):
        # Create buttons or menu items for CRUD operations
        self.student_button.pack()
        self.lecturer_button.pack()

    @staticmethod
    def open_student_form():
        student_form = StudentForm()
        student_form.grab_set()

    @staticmethod
    def open_lecturer_form():
        lecturer_form = LecturerForm()
        lecturer_form.grab_set()
