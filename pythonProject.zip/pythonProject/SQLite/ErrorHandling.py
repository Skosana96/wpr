def create_student(student_data):
    try:
        conn = sqlite3.connect('management_system.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO students (name, student_number, course) VALUES (?, ?, ?)", student_data)
        conn.commit()
    except sqlite3.IntegrityError:
        print("Error: Student already exists with the same student number.")
    finally:
        conn.close()