import sqlite3


def create_tables():
    conn = sqlite3.connect('management_system.db')
    cursor = conn.cursor()
    cursor.execute(''' CREATE TABLE IF NOT EXISTS students (
                        id INTEGER PRIMARY KEY,
                        name TEXT,
                        student_number TEXT,
                        course TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS lecturers (
                        id INTEGER PRIMARY KEY,
                        name TEXT,
                        employee_id TEXT,
                        department TEXT)''')
    conn.commit()
    conn.close()


# Call create_tables() to create the necessary tables when the application starts
create_tables()
